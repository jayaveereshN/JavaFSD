package com.ecommerce.tests;

public class Calculator1
{
    public int add(int a, int b) {
        return a + b;
    }
}
