
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Practice2servlet
 */
public class Practice2servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		
		String url ="jdbc:mysql://localhost:3306/phase2";
		String username ="root";
		String password ="#jayaN@44078";
		
		PrintWriter out = response.getWriter();
		
		Connection conn =null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			conn = DriverManager.getConnection(url, username, password);
		
			
			
		}catch(ClassNotFoundException e){
			System.err.println("No class found in sql");
		}catch(SQLException e) {
			System.err.println("Connection fail");
		}
		
		if(conn == null) {
			
			out.println("not connected");
		}else {
			out.println("connected");	
		}
		
	}

}