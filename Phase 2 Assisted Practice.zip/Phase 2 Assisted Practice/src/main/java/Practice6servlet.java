

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Practice6servlet
 */
public class Practice6servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		int id = Integer.parseInt(request.getParameter("id"));
		String data = request.getParameter("data");
		String option = request.getParameter("select");
		
		
		
		
			response.setContentType("text/html");
		
		
		String url ="jdbc:mysql://localhost:3306/phase2";
		String username ="root";
		String password ="#jayaN@44078";
		
		PrintWriter out = response.getWriter();
		
		Connection conn =null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			conn = DriverManager.getConnection(url, username, password);
			
			
			PreparedStatement stm  = null;
			
			
			
			
			
			switch(option) {
			case "insert":
				stm = conn.prepareStatement("insert into mphasis(id, name)value(?,?)");
				stm.setInt(1, id);
				stm.setString(2, data);
				
				int res= stm.executeUpdate();
				if(res ==1) {
					out.println("inserted");
				}else {
					out.println("inserted");
				}
				 
				break;
			case "update":
				stm = conn.prepareStatement("update mphasis set name =? where id = ?");
				stm.setInt(2, id);
				stm.setString(1, data);
				
				int res2= stm.executeUpdate();
				if(res2 ==1) {
					out.println("updated");
				}else {
					out.println("no record found");
				}
				 
				
				
				break;
			case "delete":
				stm = conn.prepareStatement("delete from mphasis where id=? and name =?");
				stm.setInt(1, id);
				stm.setString(2, data);
				
				int res3= stm.executeUpdate();
				if(res3 ==1) {
					out.println("deleted");
				}else {
					out.println("no record found");
				}
				 break;
			}
			
			request.getRequestDispatcher("Index4.html").include(request, response);
			
			
			Statement stm1 = conn.createStatement();
			String quer = "select * from harsha";
			ResultSet re = stm1.executeQuery(quer);
			out.println("<table><tr><th>id</th><th>name</th></tr>");
			while(re.next()) {
				out.printf("<tr><td>%s</td><td>%s</td></tr>",re.getInt("id"),re.getString("name"));
			}
			out.println("</table>");
			
			
		}catch(ClassNotFoundException e){
			System.err.println("No class found in sql");
		}catch(SQLException e) {
			System.err.println("Connection fail");
		}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		out.close();
		
		
		
		
	}



}
