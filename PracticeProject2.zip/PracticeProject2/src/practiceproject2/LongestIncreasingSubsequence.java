package practiceproject2;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LongestIncreasingSubsequence {
    public static void main(String[] args) {
        int[] arr = {10, 22, 9, 33, 21, 50, 41, 60, 80};

        List<Integer> lis = longestIncreasingSubsequence(arr);
        
        System.out.println("Longest Increasing Subsequence: " + lis);
        System.out.println("Length of Longest Increasing Subsequence: " + lis.size());
    }

    static List<Integer> longestIncreasingSubsequence(int[] arr) {
        int n = arr.length;
        int[] lisLength = new int[n];
        int[] prevIndex = new int[n];

        // Initialize LIS values for all indices
        Arrays.fill(lisLength, 1);
        Arrays.fill(prevIndex, -1);

        // Compute optimized LIS values in bottom-up manner
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (arr[i] > arr[j] && lisLength[i] < lisLength[j] + 1) {
                    lisLength[i] = lisLength[j] + 1;
                    prevIndex[i] = j;
                }
            }
        }

        // Find the maximum LIS value and its index
        int maxLISIndex = 0;
        for (int i = 1; i < n; i++) {
            if (lisLength[i] > lisLength[maxLISIndex]) {
                maxLISIndex = i;
            }
        }

        // Reconstruct the LIS
        List<Integer> lis = new ArrayList<>();
        int currentIndex = maxLISIndex;
        while (currentIndex != -1) {
            lis.add(arr[currentIndex]);
            currentIndex = prevIndex[currentIndex];
        }

        // Reverse the list to get the correct order
        Collections.reverse(lis);

        return lis;
    }
}


