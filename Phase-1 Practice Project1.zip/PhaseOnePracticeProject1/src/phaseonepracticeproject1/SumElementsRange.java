package phaseonepracticeproject1;
import java.util.Scanner;
public class SumElementsRange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the lower bound of the range (L): ");
        int L = scanner.nextInt();
        System.out.print("Enter the upper bound of the range (R): ");
        int R = scanner.nextInt();
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += i;
        }
        System.out.println("The sum of  elements in the range of " + L + " and " + R + " is: " + sum);
    }
}


