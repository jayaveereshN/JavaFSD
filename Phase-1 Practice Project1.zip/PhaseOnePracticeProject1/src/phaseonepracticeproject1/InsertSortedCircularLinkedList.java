package phaseonepracticeproject1;

	class Node1 {
	    int data;
	    Node1 next;

	    Node1(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	class SortedCircularLinkedList {
	    Node1 head;

	    SortedCircularLinkedList() {
	        this.head = null;
	    }

	    // Function to insert a new element into the sorted circular linked list
	    void insert(int newData) {
	        Node1 newNode = new Node1(newData);

	        // If the list is empty, make the new node the head and point to itself
	        if (head == null) {
	            head = newNode;
	            newNode.next = head;
	        } else if (newData <= head.data) { // If the new element is smaller or equal to the head, insert at the beginning
	            newNode.next = head;
	            head = newNode;
	        } else {
	            Node1 current = head;

	            // Traverse the list to find the correct position for the new element
	            while (current.next != head && current.next.data < newData) {
	                current = current.next;
	            }

	            // Insert the new node
	            newNode.next = current.next;
	            current.next = newNode;
	        }
	    }

	    // Function to display the elements of the circular linked list
	    void display() {
	        if (head == null) {
	            System.out.println("Circular Linked List is empty.");
	            return;
	        }

	        Node1 current = head;
	        do {
	            System.out.print(current.data + " ");
	            current = current.next;
	        } while (current != head);
	        System.out.println();
	    }
	}

	public class InsertSortedCircularLinkedList {
	    public static void main(String[] args) {
	        SortedCircularLinkedList list = new SortedCircularLinkedList();

	        // Inserting elements into the sorted circular linked list
	        list.insert(5);
	        list.insert(10);
	        list.insert(15);
	        list.insert(20);

	        System.out.println("Sorted Circular Linked List after insertion:");
	        list.display();
	    }
	}

