package phaseonepracticeproject1;


	import java.util.Stack;

	public class StackExample {
	    public static void main(String[] args) {
	        // Creating a stack
	        Stack<Integer> stack = new Stack<>();

	        // Inserting elements (push) into the stack
	        stack.push(5);
	        stack.push(10);
	        stack.push(15);
	        stack.push(20);

	        // Displaying the stack after push operations
	        System.out.println("Stack after push operations: " + stack);

	        // Removing elements (pop) from the stack
	        int poppedElement = stack.pop();
	        System.out.println("Popped element: " + poppedElement);

	        // Displaying the stack after pop operation
	        System.out.println("Stack after pop operation: " + stack);
	    }
	}

