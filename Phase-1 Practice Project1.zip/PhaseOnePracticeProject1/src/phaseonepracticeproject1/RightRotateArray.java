package phaseonepracticeproject1;

public class RightRotateArray {

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int steps = 5;

        System.out.println("Original Array: ");
        printArray(array);

        rightRotateArray(array, steps);

        System.out.println("\nArray after right rotation by " + steps + " steps: ");
        printArray(array);
    }

    // Function to right rotate an array by 'steps' steps
    private static void rightRotateArray(int[] arr, int steps) {
        int length = arr.length;

        // Normalize the number of steps
        steps = steps % length;

        // Reverse the entire array
        reverseArray(arr, 0, length - 1);

        // Reverse the first 'steps' elements
        reverseArray(arr, 0, steps - 1);

        // Reverse the remaining elements
        reverseArray(arr, steps, length - 1);
    }

    // Function to reverse an array or a subarray
    private static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {
            // Swap elements at start and end indices
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;

            // Move indices towards the center
            start++;
            end--;
        }
    }

    // Function to print an array
    private static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

