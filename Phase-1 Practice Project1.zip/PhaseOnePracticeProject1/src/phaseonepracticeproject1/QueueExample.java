package phaseonepracticeproject1;

	import java.util.LinkedList;
	import java.util.Queue;

	public class QueueExample {
	    public static void main(String[] args) {
	        // Creating a queue using LinkedList
	        Queue<Integer> queue = new LinkedList<>();

	        // Inserting elements (enqueue) into the queue
	        queue.add(5);
	        queue.add(10);
	        queue.add(15);
	        queue.add(20);

	        // Displaying the queue after enqueue operations
	        System.out.println("Queue after enqueue operations: " + queue);

	        // Removing elements (dequeue) from the queue
	        int removedElement = queue.poll();
	        System.out.println("Removed element: " + removedElement);

	        // Displaying the queue after dequeue operation
	        System.out.println("Queue after dequeue operation: " + queue);
	    }
	}


