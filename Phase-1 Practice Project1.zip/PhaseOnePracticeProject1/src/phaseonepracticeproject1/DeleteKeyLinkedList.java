package phaseonepracticeproject1;


	class Node {
	    int data;
	    Node next;

	    Node(int data) {
	        this.data = data;
	        this.next = null;
	    }
	}

	class LinkedList {
	    Node head;

	    LinkedList() {
	        this.head = null;
	    }

	    void insert(int data) {
	        Node newNode = new Node(data);
	        newNode.next = head;
	        head = newNode;
	    }

	    void deleteKey(int key) {
	        Node temp = head;
	        Node prev = null;

	        // If the key is present at the head
	        if (temp != null && temp.data == key) {
	            head = temp.next;
	            return;
	        }

	        // Search for the key to be deleted
	        while (temp != null && temp.data != key) {
	            prev = temp;
	            temp = temp.next;
	        }

	        // If the key is not present
	        if (temp == null) {
	            return;
	        }

	        // Unlink the node containing the key
	        prev.next = temp.next;
	    }

	    void display() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }
	}

	public class DeleteKeyLinkedList {
	    public static void main(String[] args) {
	        LinkedList list = new LinkedList();
	        list.insert(5);
	        list.insert(10);
	        list.insert(15);
	        list.insert(20);

	        System.out.println("Original linked list:");
	        list.display();

	        int keyToDelete = 10;
	        list.deleteKey(keyToDelete);

	        System.out.println("Linked list after deleting key " + keyToDelete + ":");
	        list.display();
	    }
	}
