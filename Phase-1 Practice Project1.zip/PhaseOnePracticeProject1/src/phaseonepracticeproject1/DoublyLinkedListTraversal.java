package phaseonepracticeproject1;

	class Node2 {
	    int data;
	    Node2 next;
	    Node2 prev;

	    Node2(int data) {
	        this.data = data;
	        this.next = null;
	        this.prev = null;
	    }
	}

	class DoublyLinkedList {
	    Node2 head;

	    DoublyLinkedList() {
	        this.head = null;
	    }

	    // Function to insert a new node at the end of the doubly linked list
	    void insert(int newData) {
	        Node2 newNode = new Node2(newData);

	        if (head == null) {
	            head = newNode;
	        } else {
	            Node2 current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	            newNode.prev = current;
	        }
	    }

	    // Function to traverse the doubly linked list in forward direction
	    void traverseForward() {
	        System.out.println("Forward traversal:");

	        Node2 current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }

	        System.out.println();
	    }

	    // Function to traverse the doubly linked list in backward direction
	    void traverseBackward() {
	        System.out.println("Backward traversal:");

	        Node2 current = head;
	        while (current != null && current.next != null) {
	            current = current.next;
	        }

	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.prev;
	        }

	        System.out.println();
	    }
	}

	public class DoublyLinkedListTraversal {
	    public static void main(String[] args) {
	    	DoublyLinkedList list = new DoublyLinkedList();
	    	
	    	//traverseForward list1 = new traverseForward();
	    	//DoublyLinkedListTraversal list2 = new DoublyLinkedListTraversal();


	        // Inserting elements into the doubly linked list
	        list.insert(5);
	        list.insert(10);
	        list.insert(15);
	        list.insert(20);

	        // Traversing the doubly linked list in forward direction
	        list.traverseForward();

	        // Traversing the doubly linked list in backward direction
	        list.traverseBackward();
	    }
	}


