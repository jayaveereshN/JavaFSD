package phaseonepracticeproject1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class UnsortedArray {

    public static void main(String[] args) {
        ArrayList<Integer> num = new ArrayList<>(Arrays.asList(13,52,16,7,90,24,56));
        Set<Integer> num1 = new HashSet<>(num);
        ArrayList<Integer> List = new ArrayList<>(num1);

        Collections.sort(List);

        if (List.size() >= 4) {
            System.out.println("The fourth smallest element is: " + List.get(3));
        } else {
            System.out.println("There are less than 4 unique elements in the list.");
        }
    }
}
