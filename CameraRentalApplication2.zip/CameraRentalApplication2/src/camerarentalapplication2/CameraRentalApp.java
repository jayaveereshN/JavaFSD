package camerarentalapplication2;



	import java.util.ArrayList;
	import java.util.List;
	import java.util.Scanner;

	class User { 
	    private String username; 
	    private String password; 
	    private double walletBalance; 
	 
	    public User(String username, String password) { 
	        this.username = username; 
	        this.password = password; 
	        this.walletBalance = 30000; 
	    } 
	 
	    public String getUsername() { 
	        return username; 
	    } 
	 
	    public String getPassword() { 
	        return password; 
	    } 
	 
	    public double getWalletBalance() { 
	        return walletBalance; 
	    } 
	    public void depositToWallet(double amount) { 
	        walletBalance += amount; 
	        System.out.println("AMOUNT DEPOSITED SUCCESSFULLY. CURRENT WALLET BALANCE: " + walletBalance); 
	    } 

	}
	class Camera { 
	    private int cameraId; 
	    private String brand; 
	    private String model; 
	    private double rentalPricePerDay; 
	    private boolean rented; 
	 
	    public Camera(int cameraId, String brand, String model, double rentalPricePerDay) { 
	        this.cameraId = cameraId; 
	        this.brand = brand; 
	        this.model = model; 
	        this.rentalPricePerDay = rentalPricePerDay; 
	        this.rented = false; 
	    } 
	 
	    public int getCameraId() { 
	        return cameraId; 
	    } 
	 
	    public String getBrand() { 
	        return brand; 
	    } 
	 
	    public String getModel() { 
	        return model; 
	    } 
	 
	    public double getRentalPricePerDay() { 
	        return rentalPricePerDay; 
	    } 
	 
	    public boolean isRented() { 
	        return rented; 
	    } 
	 
	    public void setRented(boolean rented) { 
	        this.rented = rented; 
	    } 
	}

	public class CameraRentalApp {
	    private static Scanner scanner = new Scanner(System.in); 
	    private static List<Camera> cameraList = new ArrayList<>(); 
	    private static User currentUser; 
	 
	    public static void main(String[] args) { 
	        populateCameraList(); // Populate some initial camera data 
	 
	        boolean running = true; 
	 
	        while (running) { 
	          System.out.println("+---------------+------------------- +"); 
	            System.out.println("|WELCOME TO THE CAMERA RENTAL APP!|"); 
	            System.out.println("+---------------+-----------------+"); 
	            if (currentUser == null) { 
	                LoginMenu(); 
	                int choice = scanner.nextInt(); 
	                scanner.nextLine(); 
	 
	                switch (choice) { 
	                    case 1: 
	                    	loginUser(); 
	                        break; 
	                    case 2: 
	                        running = false; 
	                        break; 
	                    default: 
	                        System.out.println("INVALID CHOICE. PLEASE TRY AFTER SOMETIME!, THANK YOU"); 
	                } 
	            } 
	            else { 
	             UserMenu(); 
	                int choice = scanner.nextInt(); 
	                scanner.nextLine(); 
	 
	                switch (choice) { 
	                    case 1: 
	                        displayCameras(); 
	                        break; 
	                    case 2: 
	                        rentCamera(); 
	                        break; 
	                    case 3: 
	                        listCameras(); 
	                        break; 
	                    case 4: 
	                        displayWalletBalance(); 
	                        break; 
	                    case 5: 
	                        logoutUser(); 
	                        break; 
	                    default: 
	                        System.out.println("INVALID CHOICE. PLEASE TRY AFTER SOMETIME!");
	                }
	            }
	        }
	    }
	    
		private static void loginUser() {
			
	        System.out.print("Enter username: "); 
	        String username = scanner.nextLine(); 
	 
	        System.out.print("Enter password: "); 
	        String password = scanner.nextLine(); 
	 
	         
	        currentUser = new User(username, password); 
	        System.out.println("LOGIN SUCCESSFULL NOW YOU CAN ACCESS OUR APPLICATION."); 
		}	
	    private static void logoutUser() { 
	        currentUser = null; 
	        System.out.println("LOGOUT SUCCESSFULL!");
	        System.out.println("+-------------------------------------------------+");
	        System.out.println("|   THANK YOU FOR USING THE CAMERA RENTAL APP! |");
	        System.out.println("+-------------------------------------------------+");
	    }
		private static void LoginMenu() {
	        System.out.println("---------------------------"); 
	        System.out.println("1. LOGIN"); 
	        System.out.println("2. EXIT"); 
	        System.out.println("---------------------------"); 
	        System.out.print("ENTER  YOUR CHOICE: "); 
		}
		private static void UserMenu() {
		System.out.println("WELCOME, " + currentUser.getUsername() + "!"); 
	        System.out.println("---------------------------"); 
	        System.out.println("1. MY CAMERA"); 
	        System.out.println("2. RENT A CAMERA"); 
	        System.out.println("3. VIEW All CAMERA'S"); 
	        System.out.println("4. MANAGE WALLET"); 
	        System.out.println("5. EXIT"); 
	        System.out.println("---------------------------"); 
	        System.out.print("ENTER YOUR CHOICE: "); 

		}
	    private static void displayCameras() { 
	        while (true) { 
	            System.out.println("---------------------------"); 
	            System.out.println("1. ADD A CAMERA"); 
	            System.out.println("2. REMOVE A CAMERA");
	            System.out.println("3. VIEW ALL CAMERA'S");
	            System.out.println("4. GO BACK TO PREVIOUS MENU"); 
	            System.out.println("---------------------------"); 
	            System.out.print("ENTER YOUR CHOICE: "); 
	            int choice = scanner.nextInt(); 
	            scanner.nextLine();
	 
	            switch (choice) { 
	                case 1: 
	                    addCamera(); 
	                    break;
	                case 2: 
	                    removeCamera(); 
	                    break;
	                case 3: 
	                	listCameras(); 
	                    break; 
	                case 4: 
	                    return; // Go back to the previous menu 
	                default:
	                 System.out.println("INVALID CHOICE. PLEASE TRY AFTER SOMETIME!"); 
	            } 
	        } 
	    }
	    
	    private static void populateCameraList() { 
	        cameraList.add(new Camera(1, "Sumung", "DS123", 500.0)); 
	        cameraList.add(new Camera(2, "Sony ", "HD214", 1500.0)); 
	        cameraList.add(new Camera(3, "vivo",  "Xc",   700.0));
	        cameraList.add(new Camera(4, "Canon", "XLR", 10000.0));
	        cameraList.add(new Camera(5, "canon","5050", 25000.0));
	    }
	    private static void listCameras() { 
	        if (cameraList.isEmpty()) { 
	            System.out.println("NO DATA PRESENT AT THE MOMENT."); 
	        } 
	        else { 
	            System.out.println("======AVLIABLE CAMERA'S:======"); 
	            // for (Camera camera : cameraList) { 
	            System.out.println("============================================================"); 
	            System.out.println("cameraId     Brand       Model       Rent per Day      status"); 
	            System.out.println("============================================================"); 
	             for (Camera camera : cameraList) { 
	                 System.out.printf("%-5s      %-7s      %-13s    $%-12.2f %-10s \n", 
	                		 camera.getCameraId(),camera.getBrand(), camera.getModel(), camera.getRentalPricePerDay(),(camera.isRented() ? "Rented" : "Available")); 
	            } 
	               
	              System.out.println("============================================================="); 
	          }        
	    } 

	    private static void addCamera() { 
	        System.out.print("ENTER CAMERA ID: "); 
	        int cameraId = scanner.nextInt(); 
	        scanner.nextLine(); 
	 
	        System.out.print("ENTER CAMERA BRAND: "); 
	        String brand = scanner.nextLine(); 
	 
	        System.out.print("ENTER CAMERA MODEL: "); 
	        String model = scanner.nextLine(); 
	 
	        System.out.print("ENTER RENTAL PRICE PER DAY: "); 
	        double rentalPricePerDay = scanner.nextDouble(); 
	        scanner.nextLine(); 
	 
	        Camera camera = new Camera(cameraId, brand, model, rentalPricePerDay);
	        cameraList.add(camera); 
	        System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST."); 
	    } 

	    private static void removeCamera() { 
	        System.out.print("ENTER CAMERA ID TO REMOVE: "); 
	        int cameraId = scanner.nextInt(); 
	        scanner.nextLine(); 
	 
	        boolean found = false; 
	        for (Camera camera : cameraList) { 
	            if (camera.getCameraId() == cameraId) { 
	                cameraList.remove(camera); 
	                found = true; 
	                System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST"); 
	                break; 
	            } 
	        } 
	 
	        if (!found) { 
	            System.out.println("CAMERA NOT FOUND."); 
	        } 
	    } 
	    private static void rentCamera() { 
	        System.out.print("ENTER CAMERA ID TO RENT: "); 
	        int cameraId = scanner.nextInt(); 
	        scanner.nextLine(); 
	 
	        Camera selectedCamera = null; 
	        for (Camera camera : cameraList) { 
	            if (camera.getCameraId() == cameraId) { 
	                selectedCamera = camera; 
	                break; 
	            } 
	        } 
	 
	        if (selectedCamera != null) { 
	            if (selectedCamera.isRented()) { 
	                System.out.println("CAMERA IS ALREADY RENTED."); 
	            } 
	            else { 
	                if (currentUser.getWalletBalance() >= selectedCamera.getRentalPricePerDay()) { 
	                    currentUser.depositToWallet(-selectedCamera.getRentalPricePerDay()); 
	                    selectedCamera.setRented(true); 
	                    System.out.println("YOUR CAMERA WAS RENTED SUCCESSFULLY!"); 
	                } 
	                else { 
	                 System.out.println("+----------------------------------------------------------------+");
	                    System.out.println("|   INSUFFICIENT BALANCE IN YOUR WALLET TO RENT A CAMERA.     |"); 
	                    System.out.println("+----------------------------------------------------------------+");
	                } 
	            } 
	        } 
	        else { 
	            System.out.println("CAMERA NOT FOUND."); 
	        } 
	    }
	    
	    private static void displayWalletBalance() { 
	        while (true) { 
	            System.out.println("---------------------------"); 
	            System.out.println("1. DEPOSITE MONEY"); 
	            System.out.println("2. SHOW AVALIABLE BALANCE"); 
	            System.out.println("3. GO BACK TO PREVIOUS MENU"); 
	            System.out.println("---------------------------"); 
	            System.out.print("ENTER YOUR CHOICE: "); 
	            int choice = scanner.nextInt(); 
	            scanner.nextLine(); 
	 
	            switch (choice) { 
	                case 1: 
	                    depositToWallet(); 
	                    break; 
	                case 2: 
	                    showAvailableBalance(); 
	                    break; 
	                case 3: 
	                    return; // Go back to the previous menu 
	                default: 
	                    System.out.println("INVALID CHOICE PLEASE TRY AGAIN!."); 
	            } 
	        } 
	    }
		private static void depositToWallet() {
			
	        System.out.print("ENTER THE AMOUNT TO DEPOSIT: "); 
	        double amount = scanner.nextDouble(); 
	        scanner.nextLine(); 
	        
	        currentUser.depositToWallet(amount); 
	        System.out.println("AMOUNT DEPOSITED SUCCESSFULLLY!"); 
	        
	        System.out.print("DO YOU WANT TO DEPOSIT MORE? (Y/N): "); 
	        String choice = scanner.nextLine().toLowerCase(); 
	 
	        if (choice.equals("Y")) { 
	            depositToWallet(); // Recursively call the depositToWallet() method 
	        } 
	    } 
	private static void showAvailableBalance() {
	 double balance = currentUser.getWalletBalance(); 
		 System.out.println("AVALIABLE BALANCE: $" + balance); 
		    } 

	}

