/**
 * 
 */
/**
 * 
 */
module CameraRentalApplication2 {
}