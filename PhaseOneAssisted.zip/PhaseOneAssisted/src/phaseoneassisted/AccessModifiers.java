package phaseoneassisted;
import java.util.Scanner;

class  DeAccess
 {
	void d1(int id1)
	{
		System.out.println("default Method is using ");

		System.out.println("integer is " +id1);
	}
 }

	class PubAccess
	{
	public void d2(int id2){
		System.out.println("public  Method is using ");

		System.out.println("integer is " +id2);
	}
	}
	class Proaccess {
		
	protected void d3(int id3){
		System.out.println("Protected Method is using ");
		System.out.println("integer is " +id3);
	}
	}
	
	//private void d4(int id4) {
	//	System.out.println("integer is");}   
	//private method cannot access outside of the class
	
 

 
public class AccessModifiers
{

	
public static void main(String[]args)
{
	DeAccess d=new DeAccess();     // Creating a class object 

	
	PubAccess pb=new PubAccess();  // Creating a class object 
	
	
	Proaccess pt=new Proaccess();    // Creating a class object 
	
	
	Scanner scan=new Scanner(System.in);
	
	System.out.println("enter the id1 ");
	int id1=scan.nextInt(); // Entering the id1 by the user
	
	System.out.println("enter the id2 ");
	int id2=scan.nextInt(); // Entering the id2 by the user
	
	System.out.println("enter the id3 ");
	int id3=scan.nextInt(); // Entering the id3 by the user
	
	//*System.out.println("enter the id4 ");
	//int id4=scan.nextInt()
	d.d1(id1);  
	           // invoking the method by using the class object
    pb.d2(id2);
               // invoking the method by using the class object
	pt.d3(id3);
	           // invoking the method by using the class object
	//a.d4(id4);
	
}
}
