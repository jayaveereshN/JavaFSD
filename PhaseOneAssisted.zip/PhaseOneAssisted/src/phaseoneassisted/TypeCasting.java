package phaseoneassisted;

public class TypeCasting {
	    public static void main(String[] args) {
	        // Implicit casting (Widening)
	        int a = 10;
	        double d = a; // Implicit casting from int to double

	        System.out.println("Implicit Casting (Widening):");
	        System.out.println("int value: " + a);
	        System.out.println("double value: " + d);
	        System.out.println();

	        // Explicit casting (Narrowing)
	        double d1= 15.75;
	        int a1= (int) d1; // Explicit casting from double to int

	        System.out.println("Explicit Casting (Narrowing):");
	        System.out.println("double value: " + d1);
	        System.out.println("int value: " + a1);

	        // Note: When narrowing, there may be a loss of data
	    }
	}


