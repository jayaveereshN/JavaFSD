package phaseoneassisted;

//method demo
class Execution {
	
	
		public int multipynumbers(int a,int b)
		{
			int z=a*b;
			return z;
		}
}

		//call by value
	class callMethod {
		
		int val=150;

		int operation(int val) {
			val =val*10/100;
			return(val);
		}
		}
		
		
	     //method overloading
		class overloadMethod {
					
		  public void area(int b,int h)
	       {
	       System.out.println("Area of Triangle : "+(0.5*b*h));
		    }
	      public void area(int r) 
		    {
		      System.out.println("Area of Circle : "+(3.14*r*r));
		       }
		}
		
	 
public class methodExecution {
	      
	        public static void main(String[] args) {
			
			

			    Execution b=new Execution();
			    int ans= b.multipynumbers(10,3);
			    System.out.println("Multipilcation is :"+ans);

			    callMethod  b1=new callMethod();
				System.out.println("Before operation value of data is "+b1.val);
				b1.operation(100);
				System.out.println("After operation value of data is "+b1.val);
				
				overloadMethod b2=new overloadMethod();
			     b2.area(10,12);
				 b2.area(5);
		}
	  }

	   
		
