




import java.io.IOException;
import jakarta.servlet.ServletException; 
import jakarta.servlet.http.HttpServlet; 
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class AddProduct extends HttpServlet {

private static final long serialVersionUID =1L;
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
{

// Retrieve form data
 
int ID=Integer.parseInt(request.getParameter("ID"));


String name = request.getParameter("name");


double price = Double.parseDouble(request.getParameter("price"));

// Validate form data

if (name.isEmpty() || price==0) {


response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing information");

return;

}

// Create a Product object with form data 
Product product = new Product();
product.setId(ID); product.setName(name); product.setPrice(price);

// Save the product using Hibernate

/* ProductDAO productDAO = new ProductDAO(); */
product.saveProduct(product); // Redirect to a success page 
response.sendRedirect("success.jsp");

}

}
