package phaseonepracticeproject;

	class MyThread extends Thread {

		public void run()
	 	{
	  		System.out.println("concurrent thread started running..");
	      }
	}

		public class ThreadExample{
	 	public static void main( String args[] )
	 	{
	  		MyThread mt1 = new  MyThread();
	  		mt1.start();
	  		
	  		MyThread mt2 = new  MyThread();
	  	    mt2.start();
	  		

	    }
	}

