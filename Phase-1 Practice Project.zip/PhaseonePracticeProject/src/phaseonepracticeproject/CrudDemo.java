package phaseonepracticeproject;

	import java.io.IOException;
	import java.nio.file.Files;
	import java.nio.file.Path;
	import java.nio.file.Paths;
	import java.nio.file.StandardOpenOption;
	import java.util.List;

		public class CrudDemo {
			

	    public static void main(String[] args) {
	        // File path
	        String filePath = "example.txt";

	        // Create operation
	        createFile(filePath, "Hello, this is a file handling example.");

	        // Read operation
	        readFile(filePath);

	        // Update operation
	        updateFile(filePath, "Updated content.");

	        // Read again after update
	        readFile(filePath);

	        // Delete operation
	        deleteFile(filePath);
	    }

	    // Create operation
	    private static void createFile(String filePath, String content) {
	        try {
	            Path path = Paths.get(filePath);
	            Files.write(path, content.getBytes());
	            System.out.println("File created successfully.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    // Read operation
	    private static void readFile(String filePath) {
	        try {
	            List<String> lines = Files.readAllLines(Paths.get(filePath));
	            System.out.println("File content:");
	            for (String line : lines) {
	                System.out.println(line);
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    // Update operation
	    private static void updateFile(String filePath, String updatedContent) {
	        try {
	            Path path = Paths.get(filePath);
	            Files.write(path, updatedContent.getBytes(), StandardOpenOption.TRUNCATE_EXISTING);
	            System.out.println("File updated successfully.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
        //delete operation
	    private static void deleteFile(String filePath) {
	        try {
	            Path path = Paths.get(filePath);
	            Files.deleteIfExists(path);
	            System.out.println("File deleted successfully.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}



