

	import java.util.regex.Matcher;
	import java.util.regex.Pattern;

	public class EmailValidator {

	    // Regular expression for basic email validation
	    private static final String EMAIL_PATTERN =
	            "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

	    private static final Pattern pattern = Pattern.compile(EMAIL_PATTERN);

	    public static boolean validateEmail(String email) {
	        Matcher matcher = pattern.matcher(email);
	        return matcher.matches();
	    }

	    public static void main(String[] args) {
	        // Test email addresses
	        String[] emails = {
	                "john.doe@example.com",
	                "alice.smith123@gmail.com",
	                "invalid.email@com",
	                "missing.at.sign.com",
	                "no.domain@dot"
	        };

	        // Validate and print results
	        for (String email : emails) {
	            System.out.println("Email: " + email + " - Valid: " + validateEmail(email));
	        }
	    }
	}
