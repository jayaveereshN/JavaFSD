
	import java.util.Scanner;

	public class Calculator {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Get user input
	        System.out.print("Enter the first number: ");
	        double num1 = scanner.nextDouble();

	        System.out.print("Enter the second number: ");
	        double num2 = scanner.nextDouble();

	        // Display menu
	        System.out.println("Select operation:");
	        System.out.println("1. Addition");
	        System.out.println("2. Subtraction");
	        System.out.println("3. Multiplication");
	        System.out.println("4. Division");

	        // Get user choice
	        System.out.print("Enter choice (1/2/3/4): ");
	        int choice = scanner.nextInt();

	        // Perform calculation based on user choice
	        double result = 0;
	        char operation = ' ';
	        switch (choice) {
	            case 1:
	                result = add(num1, num2);
	                operation = '+';
	                break;
	            case 2:
	                result = subtract(num1, num2);
	                operation = '-';
	                break;
	            case 3:
	                result = multiply(num1, num2);
	                operation = '*';
	                break;
	            case 4:
	                result = divide(num1, num2);
	                operation = '/';
	                break;
	            default:
	                System.out.println("Invalid input. Please enter a valid operation (1/2/3/4).");
	                System.exit(0);
	        }

	        // Display the result
	        System.out.println(num1 + " " + operation + " " + num2 + " = " + result);
	    }

	    private static double add(double x, double y) {
	        return x + y;
	    }

	    private static double subtract(double x, double y) {
	        return x - y;
	    }

	    private static double multiply(double x, double y) {
	        return x * y;
	    }

	    private static double divide(double x, double y) {
	        if (y != 0) {
	            return x / y;
	        } else {
	            System.out.println("Error: Division by zero");
	            System.exit(0);
	            return 0; // This is here to satisfy the return type, but the program will never reach here
	        }
	    }
	}

