package phaseonepracticeproject2;
import java.util.Scanner;
public class LinearSearch {
	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
//		System.out.println("enter array length"); (use input)
//		int n =scan.nextInt();
//		int arr[]=new int[n]; 
	int arr[]= {1,2,3,4,5,6,7}; //(default)
//		System.out.println("enter array elements");
//		for (int i=0;i<=arr.length-1;i++) {
//			System.out.println("enter an element");
//			arr[i]=scan.nextInt();
		
//		}
		// System.out.println("array elements are " + arr[i]);
	
		System.out.println("enter key element");
	 int key=scan.nextInt();
	for (int i=0;i<=arr.length-1;i++) {
		if(key==arr[i]) {
			System.out.println("key found at index " +i);
            System.exit(0);
            
		}
		}
		
		System.out.println(" key not found at any index");
}
}



