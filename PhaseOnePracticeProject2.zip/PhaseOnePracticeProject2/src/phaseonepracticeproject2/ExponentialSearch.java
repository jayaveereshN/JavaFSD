package phaseonepracticeproject2;

public class ExponentialSearch {
	    public static void main(String[] args) {
	        int[] sortedArray = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29};

	        int targetElement = 11;
	        int result = exponentialSearch(sortedArray, targetElement);

	        if (result == -1) {
	            System.out.println("Element " + targetElement + " not found in the array.");
	        } else {
	            System.out.println("Element " + targetElement + " found at index " + result + ".");
	        }
	    }

	    // Exponential search algorithm
	    public static int exponentialSearch(int[] array, int target) {
	        int n = array.length;

	        // If the target element is present at the first position
	        if (array[0] == target) {
	            return 0;
	        }

	        // Find the range for binary search by repeated doubling
	        int i = 1;
	        while (i < n && array[i] <= target) {
	            i *= 2;
	        }

	        // Perform binary search within the identified range
	        return binarySearch(array, target, i / 2, Math.min(i, n - 1));
	    }

	    // Binary search algorithm
	    public static int binarySearch(int[] array, int target, int left, int right) {
	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            // Check if target is present at mid
	            if (array[mid] == target) {
	                return mid;
	            }

	            // If target greater, ignore the left half
	            if (array[mid] < target) {
	                left = mid + 1;
	            }

	            // If target is smaller, ignore the right half
	            else {
	                right = mid - 1;
	            }
	        }

	        // If we reach here, the element was not present
	        return -1;
	    }
	}

